//
//  MIDIManager.swift
//  Torso S4 Controller
//
//  MIDI device enumeration and management

import Foundation
import CoreMIDI

class MIDIManager: ObservableObject {
    @Published var outputDevices: [MIDIDevice] = []
    @Published var inputDevices: [MIDIDevice] = []
    @Published var isConnected: Bool = false
    
    private var midiClient: MIDIClientRef = 0
    
    struct MIDIDevice: Identifiable {
        let id: Int
        let name: String
    }
    
    init() {
        setupMIDI()
    }
    
    private func setupMIDI() {
        // Create MIDI client
        var client: MIDIClientRef = 0
        let status = MIDIClientCreate("S4Controller" as CFString, nil, nil, &client)
        
        guard status == noErr else {
            print("Failed to create MIDI client: \(status)")
            return
        }
        
        self.midiClient = client
        
        // Enumerate devices
        updateDeviceList()
    }
    
    func updateDeviceList() {
        var outputs: [MIDIDevice] = []
        var inputs: [MIDIDevice] = []
        
        // Get MIDI destinations (outputs to synth)
        let destCount = MIDIGetNumberOfDestinations()
        for i in 0..<destCount {
            let dest = MIDIGetDestination(i)
            if let name = getMIDIDeviceName(dest) {
                outputs.append(MIDIDevice(id: Int(dest), name: name))
            }
        }
        
        // Get MIDI sources (inputs from controller)
        let sourceCount = MIDIGetNumberOfSources()
        for i in 0..<sourceCount {
            let source = MIDIGetSource(i)
            if let name = getMIDIDeviceName(source) {
                inputs.append(MIDIDevice(id: Int(source), name: name))
            }
        }
        
        DispatchQueue.main.async {
            self.outputDevices = outputs
            self.inputDevices = inputs
            self.isConnected = !outputs.isEmpty || !inputs.isEmpty
        }
    }
    
    private func getMIDIDeviceName(_ ref: MIDIEndpointRef) -> String? {
        var cfName: Unmanaged<CFString>?
        let status = MIDIObjectGetStringProperty(ref, kMIDIPropertyName, &cfName)
        
        guard status == noErr, let cfString = cfName else {
            return nil
        }
        
        return cfString.takeRetainedValue() as String
    }
    
    func sendControlChange(cc: UInt8, value: UInt8, to destination: MIDIEndpointRef) {
        // Placeholder for MIDI CC sending
        // Real implementation would use MIDISend with proper packet construction
        print("Send CC \(cc) = \(value) to \(destination)")
    }
    
    deinit {
        if midiClient > 0 {
            MIDIClientDispose(midiClient)
        }
    }
}
